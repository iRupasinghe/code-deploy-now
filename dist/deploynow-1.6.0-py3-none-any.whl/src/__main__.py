from .deploynow import main

main()